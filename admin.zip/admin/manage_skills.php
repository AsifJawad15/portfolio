<?php
session_start();
if (!isset($_SESSION['admin'])) { header("Location: login.php"); exit(); }
include '../includes/config.php';

if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $conn->prepare("DELETE FROM skills WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: manage_skills.php?m=deleted");
    exit();
}

$res = $conn->query("SELECT * FROM skills ORDER BY category, sort_order, id");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Manage Skills</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<header class="header">
  <a href="dashboard.php" class="logo">Admin Panel</a>
<nav class="navbar">
  <a href="dashboard.php">Dashboard</a>
  <a href="manage_projects.php">Projects</a>
  <a href="manage_credentials.php">Credentials</a>
  <a href="manage_contacts.php">Contacts</a>
  <a href="manage_skills.php">Manage Skills</a>
  <a href="add_skill.php">Add Skill</a>
  <a href="../index.php">Back</a>
  <a href="logout.php">Logout</a>
</nav>

</header>

<main style="margin-top:80px;padding:20px 5%;">
  <h2>Manage Skills</h2>
  <?php if (isset($_GET['m'])): ?>
    <p class="success"><?php echo htmlspecialchars($_GET['m']); ?></p>
  <?php endif; ?>
  <table>
    <thead><tr><th>ID</th><th>Name</th><th>Percentage</th><th>Category</th><th>Sort</th><th>Actions</th></tr></thead>
    <tbody>
      <?php while ($row = $res->fetch_assoc()): ?>
      <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo htmlspecialchars($row['name']); ?></td>
        <td><?php echo (int)$row['percentage']; ?>%</td>
        <td><?php echo htmlspecialchars($row['category']); ?></td>
        <td><?php echo (int)$row['sort_order']; ?></td>
        <td>
          <a href="edit_skill.php?id=<?php echo $row['id']; ?>">Edit</a> |
          <a href="manage_skills.php?action=delete&id=<?php echo $row['id']; ?>" onclick="return confirm('Delete this skill?')">Delete</a>
        </td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</main>
<script src="../script.js"></script>
</body>
</html>
