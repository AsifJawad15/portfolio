<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
include '../includes/config.php';

// Deletion
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM credentials WHERE id=$id");
    header("Location: manage_credentials.php");
    exit();
}

// Fetch
$result = $conn->query("SELECT * FROM credentials ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Manage Credentials</title>
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../css/style.css">
  <style>
    .credentials-grid { display:grid; grid-template-columns: repeat(3,1fr); gap:20px; margin-top:20px; }
    .credential-card { background:#fff; border:1px solid #ddd; padding:15px; border-radius:6px; position:relative; }
    .credential-card img { width:100%; height:auto; border-radius:4px; margin-bottom:10px; }
    .action-buttons { position:absolute; top:10px; right:10px; display:flex; gap:8px; }
    .action-buttons a { text-decoration:none; padding:6px 8px; background:#7A73D1; color:#fff; border-radius:4px; font-size:0.9rem; }
  </style>
</head>
<body>
  <main style="padding:20px;">
    <h2>Manage Credentials</h2>
    <p><a href="add_credential.php"><i class='bx bx-plus'></i> Add New Credential</a></p>

    <div class="credentials-grid">
      <?php if ($result->num_rows > 0): while ($row = $result->fetch_assoc()): ?>
        <div class="credential-card">
          <div class="action-buttons">
            <a href="edit_credential.php?id=<?= $row['id'] ?>">Edit</a>
            <a href="manage_credentials.php?delete=<?= $row['id'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
          </div>
          <?php if (!empty($row['image'])): ?>
            <img src="../images/<?= htmlspecialchars($row['image']) ?>" alt="Image">
          <?php endif; ?>
          <h3><?= htmlspecialchars($row['name']) ?></h3>
          <p><?= nl2br(htmlspecialchars($row['description'])) ?></p>
          <?php if (!empty($row['certificate_image'])): ?>
            <p><strong>Certificate:</strong><br><img src="../images/<?= htmlspecialchars($row['certificate_image']) ?>" alt="Certificate" style="max-width:200px;"></p>
          <?php endif; ?>
        </div>
      <?php endwhile; else: ?>
        <p>No credentials found.</p>
      <?php endif; ?>
    </div>
  </main>
  <script src="../script.js"></script>
</body>
</html>
