<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
include '../includes/config.php';

if (!isset($_GET['id'])) {
    header("Location: manage_credentials.php");
    exit();
}
$id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM credentials WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result();
$cred = $res->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $description = $_POST['description'] ?? '';
    $image = $_POST['image'] ?? '';
    $certificate_image = $_POST['certificate_image'] ?? '';

    $stmt = $conn->prepare("UPDATE credentials SET name=?, description=?, image=?, certificate_image=? WHERE id=?");
    $stmt->bind_param("ssssi", $name, $description, $image, $certificate_image, $id);
    $stmt->execute();
    header("Location: manage_credentials.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Edit Credential</title>
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>
  <main style="padding:20px;">
    <h2>Edit Credential</h2>
    <form method="post">
      <label>Name:</label>
      <input type="text" name="name" value="<?php echo htmlspecialchars($cred['name']); ?>" required>

      <label>Description:</label>
      <textarea name="description"><?php echo htmlspecialchars($cred['description']); ?></textarea>

      <label>Image Filename:</label>
      <input type="text" name="image" value="<?php echo htmlspecialchars($cred['image']); ?>">

      <label>Certificate Image Filename:</label>
      <input type="text" name="certificate_image" value="<?php echo htmlspecialchars($cred['certificate_image']); ?>">

      <button type="submit">Update Credential</button>
    </form>
  </main>
  <script src="../script.js"></script>
</body>
</html>
