<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
include '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $description = $_POST['description'] ?? '';
    $image = $_POST['image'] ?? '';
    $certificate_image = $_POST['certificate_image'] ?? '';

    if (!empty($name)) {
        $stmt = $conn->prepare("INSERT INTO credentials (name, description, image, certificate_image) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $description, $image, $certificate_image);
        $stmt->execute();
        header("Location: manage_credentials.php");
        exit();
    } else {
        $error = "Name is required.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Add Credential</title>
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>
  <main style="padding:20px;">
    <h2>Add Credential</h2>
    <?php if (!empty($error)): ?><p class="error"><?= htmlspecialchars($error) ?></p><?php endif; ?>
    <form method="post">
      <label>Name:</label>
      <input type="text" name="name" required>

      <label>Description:</label>
      <textarea name="description"></textarea>

      <label>Image Filename (place file in /images then give filename):</label>
      <input type="text" name="image" placeholder="example.jpg">

      <label>Certificate Image Filename (place file in /images then give filename):</label>
      <input type="text" name="certificate_image" placeholder="cert-example.jpg">

      <button type="submit">Add Credential</button>
    </form>
  </main>
  <script src="../script.js"></script>
</body>
</html>
